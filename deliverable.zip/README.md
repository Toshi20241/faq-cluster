# FAQ 自動生成パイプライン

**目的**  
Slack の Q&A 30 件を 8 行の FAQ に集約し、確認コストを 73 % 削減。

**実行方法**  
```bash
./run_daily.sh            # faq.html が生成
```
